import { projectImages as PI } from "./projectImages";
import {
  useState,
  useRef,
  useEffect,
  useCallback,
} from "react";
import {
  X,
  Maximize2,
  Minimize2,
  ChevronDown,
  Menu,
  ExternalLink,
  ArrowUpRight,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

/* ─── Types ─────────────────────────────────────────────────────── */
interface Project {
  id: number;
  title: string;
  category: string;
  categoryKey: string;
  year: string;
  projectType: string;
  tags: string[];
  thumb: string;
  overview: string;
  role: string;
  duration: string;
  tools: string[];
  images: string[];
  details: string[];
}

/* ─── Data ───────────────────────────────────────────────────────── */
const projects: Project[] = [
  {
    id: 1,
    title: "카페 O2O 앱 리디자인",
    category: "MOBILE · UX/UI",
    categoryKey: "MOBILE",
    year: "2025",
    projectType: "팀 프로젝트",
    tags: ["Figma", "Mobile", "UX Research"],
    thumb: PI["01_cafe-app"].thumb,
    overview:
      "국내 카페 프랜차이즈 앱의 전반적인 UX 리디자인 프로젝트입니다. 사용자 인터뷰와 휴리스틱 평가를 기반으로 주문 플로우를 단순화하고, 시각적 일관성을 높였습니다.",
    role: "UX Researcher · UI Designer",
    duration: "2025.03 — 2025.06 (4개월)",
    tools: ["Figma", "Adobe Illustrator", "Notion"],
    images: [PI["01_cafe-app"].detail01, PI["01_cafe-app"].detail02],
    details: [
      "기존 앱은 주문 완료까지 평균 7단계가 소요되었으나, 리디자인 후 3단계로 단축했습니다.",
      "사용자 테스트 결과 태스크 성공률 68% → 94%로 향상되었습니다.",
      "다크 모드와 라이트 모드 완벽 지원을 위한 색상 토큰 시스템을 구축했습니다.",
      "접근성 WCAG 2.1 AA 기준을 충족하는 컬러 컨트라스트 및 터치 타겟 사이즈를 적용했습니다.",
    ],
  },
  {
    id: 2,
    title: "패션 이커머스 웹사이트",
    category: "WEB · UI Design",
    categoryKey: "WEB",
    year: "2025",
    projectType: "팀 프로젝트",
    tags: ["Figma", "Web", "E-commerce"],
    thumb: PI["02_ecommerce"].thumb,
    overview:
      "패션 브랜드의 온라인 쇼핑몰 UI 디자인 프로젝트입니다. 브랜드 아이덴티티를 반영한 고급스러운 비주얼과 직관적인 쇼핑 경험을 목표로 설계했습니다.",
    role: "UI Designer",
    duration: "2025.01 — 2025.03 (3개월)",
    tools: ["Figma", "Photoshop"],
    images: [PI["02_ecommerce"].detail01, PI["02_ecommerce"].detail02],
    details: [
      "홈, 카테고리, 상품 상세, 장바구니, 결제 플로우 풀페이지 설계",
      "그리드 기반 12컬럼 반응형 레이아웃 — 웹/태블릿/모바일 대응",
      "상품 필터 및 정렬 인터랙션 프로토타입 제작",
      "마이크로 인터랙션 및 애니메이션 가이드라인 수립",
    ],
  },
  {
    id: 3,
    title: "핀테크 대시보드",
    category: "WEB · UX/UI",
    categoryKey: "WEB",
    year: "2024",
    projectType: "개인 프로젝트",
    tags: ["Figma", "Dashboard", "UX"],
    thumb: PI["03_fintech-dashboard"].thumb,
    overview:
      "개인 자산관리 서비스의 메인 대시보드 UX/UI 설계 프로젝트입니다. 복잡한 금융 데이터를 시각적으로 명확하게 전달하는 것이 핵심 목표였습니다.",
    role: "UX/UI Designer",
    duration: "2024.09 — 2024.12 (4개월)",
    tools: ["Figma", "Adobe Illustrator"],
    images: [PI["03_fintech-dashboard"].detail01, PI["03_fintech-dashboard"].detail02],
    details: [
      "데이터 시각화 컴포넌트 20종 이상 커스텀 설계",
      "사용자 리서치 → 와이어프레임 → 프로토타입 → 사용성 테스트 전 과정 수행",
      "디자인 시스템(컴포넌트 라이브러리) 구축 및 문서화",
      "색맹·저시력 사용자를 위한 접근성 강화 색상 체계 적용",
    ],
  },
  {
    id: 4,
    title: "여행 플래너 앱",
    category: "MOBILE · UX/UI",
    categoryKey: "MOBILE",
    year: "2024",
    projectType: "개인 프로젝트",
    tags: ["Figma", "Mobile", "Travel"],
    thumb: PI["04_travel-app"].thumb,
    overview:
      "여행 일정 계획 및 공유 앱의 신규 서비스 기획 및 UI 디자인입니다. 친구들과 함께 여행을 계획하는 소셜 기능에 중점을 두었습니다.",
    role: "UX/UI Designer · Prototyper",
    duration: "2024.06 — 2024.08 (3개월)",
    tools: ["Figma", "Photoshop", "Illustrator"],
    images: [PI["04_travel-app"].detail01, PI["04_travel-app"].detail02],
    details: [
      "사용자 페르소나 3종 및 CJM(Customer Journey Map) 작성",
      "핵심 플로우 6종에 대한 고충실도 프로토타입 제작",
      "iOS/Android 가이드라인을 준수한 네이티브 앱 UI",
      "지도 기반 일정 뷰어 인터랙션 설계",
    ],
  },
  {
    id: 5,
    title: "기업 브랜드 웹사이트",
    category: "WEB · Publishing",
    categoryKey: "WEB",
    year: "2024",
    projectType: "외주 프로젝트",
    tags: ["HTML", "CSS", "JavaScript", "Figma"],
    thumb: PI["05_brand-website"].thumb,
    overview:
      "B2B SaaS 스타트업의 브랜드 웹사이트 설계 및 퍼블리싱 프로젝트입니다. 디자인부터 HTML/CSS/JS 구현까지 단독으로 진행했습니다.",
    role: "UI Designer · Front-end Publisher",
    duration: "2024.03 — 2024.05 (3개월)",
    tools: ["Figma", "HTML", "CSS", "JavaScript", "Photoshop"],
    images: [PI["05_brand-website"].detail01, PI["05_brand-website"].detail02],
    details: [
      "웹표준 및 크로스브라우저 호환성 준수 마크업",
      "CSS Grid / Flexbox 기반 반응형 레이아웃 구현",
      "Scroll 트리거 애니메이션 및 인터랙션 구현",
      "Lighthouse 성능 점수 92점 달성",
    ],
  },
  {
    id: 6,
    title: "스마트홈 IoT 앱",
    category: "MOBILE · UX/UI",
    categoryKey: "MOBILE",
    year: "2023",
    projectType: "팀 프로젝트",
    tags: ["Figma", "Mobile", "IoT", "UX"],
    thumb: PI["06_smarthome-app"].thumb,
    overview:
      "스마트홈 기기 제어 앱의 UX 리서치 및 UI 리뉴얼 프로젝트입니다. 다양한 기기를 하나의 인터페이스에서 직관적으로 제어할 수 있는 통합 경험을 설계했습니다.",
    role: "UX Researcher · UI Designer",
    duration: "2023.10 — 2024.01 (4개월)",
    tools: ["Figma", "Adobe Illustrator", "Photoshop"],
    images: [PI["06_smarthome-app"].detail01, PI["06_smarthome-app"].detail02],
    details: [
      "콘텍스추얼 인쿼이어리 기법을 활용한 현장 사용자 조사",
      "15종 IoT 기기 제어 UI 패턴 통합 설계",
      "야간 모드에서의 가독성과 눈부심 최소화 색상 시스템",
      "기기 상태 피드백을 위한 마이크로 인터랙션 설계",
    ],
  },
  {
    id: 7,
    title: "영화 포스터 제작",
    category: "CONTENT · DESIGN",
    categoryKey: "CONTENT",
    year: "2026",
    projectType: "개인 프로젝트",
    tags: ["Photoshop"],
    thumb: PI["07_movie-poster"].thumb,
    overview:
      "영화 포스터 작업물입니다.",
    role: "Photoshop · Designer",
    duration: "2026.05.07 — 2026.05.07 (3시간)",
    tools: ["Photoshop"],
    images: [PI["07_movie-poster"].detail01, PI["07_movie-poster"].detail02],
    details: [
      "의자 이미지를 사용하여 객체(고양이, 나비, 수풀 등) 합성",
      "Photoshop 내의 AI를 활용한 영화 포스터 제작",
    ],
  },
];

const skills = [
  { name: "웹표준", sub: "W3C · Accessibility" },
  { name: "Figma", sub: "UI · Prototyping" },
  { name: "Photoshop", sub: "Image · Compositing" },
  { name: "Illustrator", sub: "Vector · Icon" },
  { name: "HTML", sub: "Semantic Markup" },
  { name: "CSS", sub: "Responsive Layout" },
  { name: "JavaScript", sub: "Interaction" },
];

const NAV_ITEMS = [
  { label: "ABOUT", id: "about" },
  { label: "WORK", id: "portfolio" },
  { label: "CONTACT", id: "contact" },
];

const FILTER_TABS = ["ALL", "WEB", "MOBILE", "CONTENT"];

/* ─── Component ─────────────────────────────────────────────────── */
export default function App() {
  const [selectedProject, setSelectedProject] =
    useState<Project | null>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showTooltip, setShowTooltip] = useState(false);
  const [activeFilter, setActiveFilter] = useState("ALL");
  const [activeSection, setActiveSection] = useState("hero");
  const [menuOpen, setMenuOpen] = useState(false);
  const [heroIndex, setHeroIndex] = useState(0);
  const [scrolled, setScrolled] = useState(false);
  const tooltipTimerRef = useRef<ReturnType<
    typeof setTimeout
  > | null>(null);

  const containerRef = useRef<HTMLDivElement>(null);
  const sectionRefs = useRef<
    Record<string, HTMLElement | null>
  >({});
  const heroWords = ["WEB", "MOBILE", "UX", "UI"];

  /* Hero word cycle */
  useEffect(() => {
    const iv = setInterval(
      () => setHeroIndex((i) => (i + 1) % heroWords.length),
      1600,
    );
    return () => clearInterval(iv);
  }, []);

  /* Nav scroll shadow */
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const onScroll = () => setScrolled(el.scrollTop > 40);
    el.addEventListener("scroll", onScroll);
    return () => el.removeEventListener("scroll", onScroll);
  }, []);

  /* Active section via IntersectionObserver */
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting)
            setActiveSection(entry.target.id);
        });
      },
      { root: el, threshold: 0.45 },
    );
    Object.values(sectionRefs.current).forEach(
      (s) => s && observer.observe(s),
    );
    return () => observer.disconnect();
  }, []);

  const setRef = (id: string) => (el: HTMLElement | null) => {
    sectionRefs.current[id] = el;
  };

  const scrollTo = useCallback((id: string) => {
    sectionRefs.current[id]?.scrollIntoView({
      behavior: "smooth",
    });
    setMenuOpen(false);
  }, []);

  const openModal = (p: Project) => {
    const isMobile = window.innerWidth < 768;
    setSelectedProject(p);
    setIsFullscreen(isMobile);
    if (!isMobile) {
      setShowTooltip(true);
      if (tooltipTimerRef.current)
        clearTimeout(tooltipTimerRef.current);
      tooltipTimerRef.current = setTimeout(
        () => setShowTooltip(false),
        5000,
      );
    }
  };

  const closeModal = () => {
    setSelectedProject(null);
    setIsFullscreen(false);
    setShowTooltip(false);
    if (tooltipTimerRef.current)
      clearTimeout(tooltipTimerRef.current);
  };

  const filtered =
    activeFilter === "ALL"
      ? projects
      : projects.filter((p) => p.categoryKey === activeFilter);

  return (
    <>
      <style>{`
        /* ── Scrollbar: container ── */
        .snap-container {
          scrollbar-width: thin;
          scrollbar-color: rgba(110,231,255,0.22) transparent;
        }
        .snap-container::-webkit-scrollbar { width: 4px; }
        .snap-container::-webkit-scrollbar-track { background: transparent; }
        .snap-container::-webkit-scrollbar-thumb {
          background: rgba(110,231,255,0.22);
          border-radius: 2px;
        }
        .snap-container::-webkit-scrollbar-thumb:hover {
          background: rgba(110,231,255,0.5);
        }

        /* ── Scrollbar: modal ── */
        .modal-scroll {
          scrollbar-width: thin;
          scrollbar-color: rgba(110,231,255,0.18) transparent;
        }
        .modal-scroll::-webkit-scrollbar { width: 3px; }
        .modal-scroll::-webkit-scrollbar-track { background: transparent; }
        .modal-scroll::-webkit-scrollbar-thumb {
          background: rgba(110,231,255,0.18);
          border-radius: 2px;
        }
        .modal-scroll::-webkit-scrollbar-thumb:hover {
          background: rgba(110,231,255,0.42);
        }

        /* ── Scroll container ── */
        .snap-container {
          overflow-y: scroll;
          height: 100dvh;
          scroll-behavior: smooth;
        }

        /* ── Grid dots bg ── */
        .grid-bg {
          background-image:
            linear-gradient(rgba(110,231,255,0.06) 1px, transparent 1px),
            linear-gradient(90deg, rgba(110,231,255,0.06) 1px, transparent 1px);
          background-size: 60px 60px;
        }

        /* ── Hero word flip ── */
        @keyframes wordFlip {
          0%   { opacity: 0; transform: translateY(12px); }
          15%  { opacity: 1; transform: translateY(0); }
          85%  { opacity: 1; transform: translateY(0); }
          100% { opacity: 0; transform: translateY(-12px); }
        }
        .word-flip { animation: wordFlip 1.6s ease-in-out forwards; }

        /* ── Ticker marquee ── */
        @keyframes marquee {
          from { transform: translateX(0); }
          to   { transform: translateX(-50%); }
        }
        .marquee-inner { animation: marquee 18s linear infinite; }

        /* ── Glow pulse ── */
        @keyframes glowPulse {
          0%, 100% { opacity: 0.08; }
          50% { opacity: 0.18; }
        }
        .glow-pulse { animation: glowPulse 4s ease-in-out infinite; }

      `}</style>

      {/* ── Fixed Nav ─────────────────────────────────────── */}
      <nav
        className={`fixed top-0 left-0 right-0 z-40 flex items-center justify-between px-5 md:px-12 h-14 transition-all duration-300 ${
          scrolled
            ? "bg-background/90 backdrop-blur-md border-b border-border"
            : "bg-transparent"
        }`}
      >
        <button
          onClick={() => scrollTo("hero")}
          className="font-display text-[11px] font-bold tracking-[0.22em] text-foreground hover:text-primary transition-colors"
        >
          PORT<span className="text-primary">FOLIO</span>
        </button>

        {/* Desktop links */}
        <div className="hidden md:flex items-center gap-8">
          {NAV_ITEMS.map((item) => (
            <button
              key={item.id}
              onClick={() => scrollTo(item.id)}
              className={`text-[10px] font-bold tracking-[0.25em] transition-colors ${
                activeSection === item.id
                  ? "text-primary"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>

        {/* Mobile hamburger */}
        <button
          className="md:hidden text-foreground hover:text-primary transition-colors"
          onClick={() => setMenuOpen((v) => !v)}
          aria-label="메뉴"
        >
          {menuOpen ? <X size={18} /> : <Menu size={18} />}
        </button>
      </nav>

      {/* Mobile menu drawer */}
      <AnimatePresence>
        {menuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.18 }}
            className="fixed top-14 left-0 right-0 z-30 bg-card border-b border-border py-5 px-5 flex flex-col gap-5 md:hidden"
          >
            {NAV_ITEMS.map((item) => (
              <button
                key={item.id}
                onClick={() => scrollTo(item.id)}
                className="text-left text-[10px] font-bold tracking-[0.25em] text-foreground hover:text-primary transition-colors"
              >
                {item.label}
              </button>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── Snap scroll container ──────────────────────────── */}
      <div ref={containerRef} className="snap-container">
        {/* ════════════════════════════════════════
            HERO
        ════════════════════════════════════════ */}
        <section
          id="hero"
          ref={setRef("hero")}
          className="relative flex flex-col justify-center px-6 md:px-16 lg:px-24 h-[100dvh] overflow-hidden grid-bg"
        >
          {/* Radial glow */}
          <div
            className="absolute top-1/2 left-1/3 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full pointer-events-none glow-pulse"
            style={{
              background:
                "radial-gradient(circle, rgba(110,231,255,0.15) 0%, transparent 70%)",
            }}
          />

          <div className="relative z-10 max-w-6xl">
            {/* Label */}
            <motion.p
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.25, duration: 0.55 }}
              className="font-display text-[10px] font-bold tracking-[0.35em] text-primary mb-7"
            >
              UX/UI DESIGNER · 2026
            </motion.p>

            {/* Main heading */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.4 }}
              className="font-display font-black leading-[0.88] tracking-tighter mb-6"
              style={{
                fontSize: "clamp(3.2rem, 11vw, 9.5rem)",
              }}
            >
              <span className="text-foreground block">
                CREATIVE
              </span>
              <span className="text-primary block">
                DESIGNER
              </span>
            </motion.div>

            {/* Animated capability tags */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.7 }}
              className="flex flex-wrap gap-2.5 mb-9"
            >
              {["WEB", "MOBILE", "UX", "UI"].map((tag, i) => (
                <motion.span
                  key={tag}
                  initial={{ opacity: 0, scale: 0.78 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{
                    delay: 0.75 + i * 0.1,
                    type: "spring",
                    stiffness: 280,
                  }}
                  className="px-4 py-1.5 border border-primary/35 bg-primary/5 text-primary font-display text-[10px] font-bold tracking-[0.22em]"
                >
                  {tag}
                </motion.span>
              ))}
            </motion.div>

            {/* Bio line */}
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1.1 }}
              className="text-muted-foreground text-sm md:text-base max-w-md leading-relaxed"
            >
              사용자 중심 사고로 디자인하는 UX/UI
              디자이너입니다.
              <br className="hidden sm:block" />
              웹과 모바일을 아우르는 통합적 디지털 경험을
              설계합니다.
            </motion.p>
          </div>

          {/* Scroll down */}
          <motion.button
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.4 }}
            onClick={() => scrollTo("about")}
            className="absolute bottom-10 left-6 md:left-16 lg:left-24 flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors group"
          >
            <ChevronDown size={14} className="animate-bounce" />
            <span className="font-display text-[9px] tracking-[0.3em]">
              SCROLL
            </span>
          </motion.button>

          {/* Decorative year */}
          <div className="absolute bottom-6 right-6 md:right-16 font-display text-[5rem] md:text-[8rem] font-black text-foreground/[0.025] select-none leading-none pointer-events-none">
            2026
          </div>
        </section>

        {/* Marquee divider */}
        <div className="bg-primary/5 border-y border-primary/15 overflow-hidden py-3 shrink-0">
          <div className="marquee-inner flex gap-12 whitespace-nowrap w-max">
            {Array.from({ length: 10 }).map((_, i) => (
              <span
                key={i}
                className="font-display text-[10px] font-bold tracking-[0.3em] text-primary/50"
              >
                WEB DESIGN · MOBILE UI · UX RESEARCH · FIGMA ·
                PUBLISHING · HTML / CSS / JS ·&nbsp;
              </span>
            ))}
          </div>
        </div>

        {/* ════════════════════════════════════════
            ABOUT
        ════════════════════════════════════════ */}
        <section
          id="about"
          ref={setRef("about")}
          className="min-h-[100dvh] flex flex-col justify-center px-6 md:px-16 lg:px-24 py-28"
        >
          <div className="max-w-5xl w-full mx-auto">
            <motion.p
              className="font-display text-[10px] font-bold tracking-[0.3em] text-primary mb-5"
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true, amount: 0.4 }}
            >
              01 / ABOUT
            </motion.p>

            <motion.h2
              className="font-display font-black tracking-tighter text-foreground mb-14"
              style={{
                fontSize: "clamp(2.5rem, 7vw, 5.5rem)",
                lineHeight: 0.9,
              }}
              initial={{ opacity: 0, y: 22 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.4 }}
              transition={{ duration: 0.55 }}
            >
              ABOUT ME
            </motion.h2>

            <div className="grid md:grid-cols-[1fr_1fr] gap-12 md:gap-20">
              {/* Bio text */}
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, amount: 0.3 }}
                transition={{ duration: 0.55 }}
              >
                <p className="text-foreground/85 leading-relaxed mb-5">
                  안녕하세요.{" "}
                  <span className="text-primary font-medium">
                    웹/모바일 UX·UI 디자이너
                  </span>
                  입니다. 사용자 리서치를 기반으로 문제를
                  정의하고, 데이터로 검증된 솔루션을 설계하는
                  것을 지향합니다.
                </p>
                <p className="text-foreground/55 leading-relaxed mb-10">
                  Figma를 중심으로 디자인 시스템을 구축하고,
                  HTML/CSS/JS 퍼블리싱 역량을 바탕으로 개발자와
                  원활하게 협업합니다. 반응형 웹 표준과 모바일
                  가이드라인을 준수한 실용적인 디자인을
                  추구합니다.
                </p>

                <div className="flex flex-wrap gap-3">
                  <button
                    onClick={() => scrollTo("portfolio")}
                    className="px-6 py-3 bg-primary text-background font-display text-[10px] font-bold tracking-[0.2em] hover:bg-primary/80 transition-colors"
                  >
                    VIEW WORK
                  </button>
                  <button
                    onClick={() => scrollTo("contact")}
                    className="px-6 py-3 border border-border text-foreground font-display text-[10px] font-bold tracking-[0.2em] hover:border-primary hover:text-primary transition-colors"
                  >
                    CONTACT
                  </button>
                </div>
              </motion.div>

              {/* Skills grid */}
              <div>
                <p className="font-display text-[9px] font-bold tracking-[0.3em] text-muted-foreground mb-5">
                  SKILLS &amp; TOOLS
                </p>
                <div className="grid grid-cols-2 gap-2.5">
                  {skills.map((sk, i) => (
                    <motion.div
                      key={sk.name}
                      initial={{ opacity: 0, y: 10 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true, amount: 0.2 }}
                      transition={{
                        delay: i * 0.07,
                        duration: 0.4,
                      }}
                      className="group p-4 border border-border bg-card hover:border-primary/40 hover:bg-primary/5 transition-all duration-300"
                    >
                      <p className="text-foreground font-display font-bold text-[11px] tracking-wide mb-1">
                        {sk.name}
                      </p>
                      <p className="text-muted-foreground text-[10px]">
                        {sk.sub}
                      </p>
                    </motion.div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ════════════════════════════════════════
            PORTFOLIO
        ════════════════════════════════════════ */}
        <section
          id="portfolio"
          ref={setRef("portfolio")}
          className="min-h-[100dvh] px-6 md:px-16 lg:px-24 py-28"
        >
          <div className="max-w-6xl mx-auto">
            <motion.p
              className="font-display text-[10px] font-bold tracking-[0.3em] text-primary mb-5"
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true, amount: 0.3 }}
            >
              02 / WORK
            </motion.p>

            <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-6 mb-10">
              <motion.h2
                className="font-display font-black tracking-tighter text-foreground"
                style={{ fontSize: "64px", lineHeight: 0.9 }}
                initial={{ opacity: 0, y: 22 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.3 }}
                transition={{ duration: 0.55 }}
              >
                SELECTED
                <br />
                WORK
              </motion.h2>

              {/* Filter */}
              <div className="flex gap-2 shrink-0">
                {FILTER_TABS.map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setActiveFilter(tab)}
                    className={`px-4 py-1.5 border font-display text-[10px] font-bold tracking-[0.2em] transition-colors duration-200 ${
                      activeFilter === tab
                        ? "border-primary bg-primary text-background"
                        : "border-border text-muted-foreground hover:border-primary hover:text-primary"
                    }`}
                  >
                    {tab}
                  </button>
                ))}
              </div>
            </div>

            {/* Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-5">
              {filtered.map((project, i) => (
                <motion.article
                  key={project.id}
                  initial={{ opacity: 0, y: 18 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, amount: 0.15 }}
                  transition={{
                    delay: i * 0.08,
                    duration: 0.45,
                  }}
                  onClick={() => openModal(project)}
                  className="group cursor-pointer"
                >
                  {/* ── Thumbnail ── */}
                  <div className="relative overflow-hidden bg-secondary aspect-[4/3]">
                    <img
                      src={project.thumb}
                      alt={project.title}
                      className="w-full h-full object-cover transition-transform duration-700 ease-out will-change-transform group-hover:scale-[1.08]"
                    />

                    {/* Hover overlay */}
                    <div className="absolute inset-0 bg-background/0 group-hover:bg-background/55 transition-all duration-400 flex items-end p-4">
                      <span className="flex items-center gap-1.5 font-display text-[10px] font-bold tracking-[0.22em] text-primary opacity-0 translate-y-3 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-300">
                        VIEW PROJECT <ArrowUpRight size={12} />
                      </span>
                    </div>
                  </div>

                  {/* ── Card info ── */}
                  <div className="pt-3.5 pb-1">
                    <span className="font-display text-[9px] font-bold tracking-[0.25em] text-primary">
                      {project.category}
                    </span>
                    <h3 className="text-foreground font-medium text-[15px] mt-1 mb-2">
                      {project.title}
                    </h3>

                    <p className="font-display text-[9px] text-muted-foreground tracking-wide mb-2">
                      {project.year} · {project.projectType}
                    </p>

                    <div className="flex flex-wrap gap-1.5">
                      {project.tags.map((tag) => (
                        <span
                          key={tag}
                          className="font-display text-[8px] font-bold tracking-wide text-muted-foreground border border-border px-2 py-0.5"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                </motion.article>
              ))}
            </div>
          </div>
        </section>

        {/* ════════════════════════════════════════
            CONTACT
        ════════════════════════════════════════ */}
        <section
          id="contact"
          ref={setRef("contact")}
          className="min-h-[100dvh] flex flex-col justify-center px-6 md:px-16 lg:px-24 py-28 border-t border-border relative overflow-hidden"
        >
          {/* Decorative glow */}
          <div
            className="absolute bottom-0 right-0 w-[500px] h-[500px] pointer-events-none glow-pulse"
            style={{
              background:
                "radial-gradient(circle at bottom right, rgba(110,231,255,0.12) 0%, transparent 65%)",
            }}
          />

          <div className="max-w-5xl mx-auto w-full relative z-10">
            <motion.p
              className="font-display text-[10px] font-bold tracking-[0.3em] text-primary mb-5"
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true, amount: 0.4 }}
            >
              03 / CONTACT
            </motion.p>

            <motion.h2
              className="font-display font-black tracking-tighter text-foreground mb-10"
              style={{
                fontSize: "clamp(2.8rem, 8vw, 7rem)",
                lineHeight: 0.9,
              }}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.4 }}
              transition={{ duration: 0.55 }}
            >
              {"LET'S WORK"}
              <br />
              <span className="text-primary">TOGETHER</span>
            </motion.h2>

            <motion.p
              className="text-muted-foreground text-sm max-w-md leading-relaxed mb-10"
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ delay: 0.15 }}
            >
              새로운 프로젝트, 협업 제안, 또는 단순한 인사도
              환영합니다.
              <br />
              언제든지 연락주세요.
            </motion.p>

            <motion.div
              className="flex flex-wrap gap-3 mb-16"
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ delay: 0.2 }}
            >
              <a
                href="mailto:hello@portfolio.com"
                className="inline-flex items-center gap-2 px-8 py-3.5 bg-primary text-background font-display text-[10px] font-bold tracking-[0.2em] hover:bg-primary/80 transition-colors"
              >
                SEND EMAIL
              </a>
              <a
                href="#"
                className="inline-flex items-center gap-2 px-8 py-3.5 border border-border text-foreground font-display text-[10px] font-bold tracking-[0.2em] hover:border-primary hover:text-primary transition-colors"
              >
                DOWNLOAD CV <ExternalLink size={11} />
              </a>
            </motion.div>

            {/* Footer bar */}
            <div className="pt-8 border-t border-border flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <p className="font-display text-[9px] text-muted-foreground tracking-wide">
                © 2026 UX/UI Designer Portfolio. All rights
                reserved.
              </p>
              <div className="flex gap-6">
                {["Behance", "Notion", "LinkedIn"].map((s) => (
                  <a
                    key={s}
                    href="#"
                    className="font-display text-[9px] font-bold tracking-[0.2em] text-muted-foreground hover:text-primary transition-colors"
                  >
                    {s}
                  </a>
                ))}
              </div>
            </div>
          </div>
        </section>
      </div>

      {/* ════════════════════════════════════════
          MODAL
      ════════════════════════════════════════ */}
      <AnimatePresence>
        {selectedProject && (
          <motion.div
            key="backdrop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.22 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-background/75 backdrop-blur-md p-4 md:p-8"
            onClick={(e) => {
              if (e.target === e.currentTarget) closeModal();
            }}
          >
            <motion.div
              key="modal"
              initial={{ opacity: 0, scale: 0.93, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.93, y: 20 }}
              transition={{
                type: "spring",
                damping: 26,
                stiffness: 300,
              }}
              className={`relative bg-card border border-border flex flex-col ${
                isFullscreen
                  ? "fixed inset-0 w-screen h-screen"
                  : "w-full max-w-3xl max-h-[90vh]"
              }`}
            >
              {/* Modal header */}
              <div className="flex items-center justify-between px-6 py-4 border-b border-border shrink-0 bg-card">
                <div className="min-w-0 pr-4">
                  <span className="font-display text-[9px] font-bold tracking-[0.28em] text-primary block mb-0.5">
                    {selectedProject.category}
                  </span>
                  <h3 className="font-display font-bold text-base text-foreground leading-tight truncate">
                    {selectedProject.title}
                  </h3>
                </div>
                <div className="flex items-center gap-1 shrink-0">
                  {/* Fullscreen toggle */}
                  <div className="hidden md:block relative">
                    <button
                      onClick={() => setIsFullscreen((v) => !v)}
                      className="p-2 text-muted-foreground hover:text-primary transition-colors"
                    >
                      {isFullscreen ? (
                        <Minimize2 size={15} />
                      ) : (
                        <Maximize2 size={15} />
                      )}
                    </button>
                    {/* Speech bubble tooltip — 모달 첫 진입 후 5초간 표시 */}
                    <AnimatePresence>
                      {showTooltip && (
                        <motion.div
                          initial={{ opacity: 0, y: -8 }}
                          animate={{
                            opacity: 1,
                            y: [-8, 6, -3, 2, 0],
                          }}
                          exit={{
                            opacity: 0,
                            transition: {
                              duration: 0.8,
                              ease: "easeOut",
                            },
                          }}
                          transition={{
                            duration: 0.55,
                            ease: "easeOut",
                          }}
                          className="absolute top-full right-0 mt-3 z-50 pointer-events-none"
                        >
                          {/* 말풍선 꼬리 — 위를 향함 */}
                          <span
                            className="absolute bottom-full right-4 border-[5px] border-transparent"
                            style={{
                              borderBottomColor:
                                "var(--primary)",
                            }}
                          />
                          <div className="bg-primary text-background font-display text-[9px] font-bold tracking-[0.15em] whitespace-nowrap px-3.5 py-2 rounded-xl">
                            {isFullscreen
                              ? "창 모드로 보기"
                              : "전체화면으로 보기"}
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                  {/* Close */}
                  <button
                    onClick={closeModal}
                    className="p-2 text-muted-foreground hover:text-primary transition-colors"
                  >
                    <X size={15} />
                  </button>
                </div>
              </div>

              {/* Modal scrollable body */}
              <div className="modal-scroll overflow-y-auto flex-1">
                <div className="p-6 md:p-8">
                  {/* Hero image */}
                  <div className={`w-full mb-8 overflow-hidden ${isFullscreen ? "bg-transparent" : "bg-secondary"}`}>
                    <img
                      src={selectedProject.images[0]}
                      alt={selectedProject.title}
                      className={isFullscreen ? "mx-auto max-w-full h-auto" : "w-full h-auto"}
                    />
                  </div>

                  {/* Meta info */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 p-5 bg-secondary/40 border border-border mb-8">
                    <div>
                      <p className="font-display text-[9px] font-bold tracking-[0.28em] text-muted-foreground mb-1.5">
                        ROLE
                      </p>
                      <p className="text-foreground text-sm">
                        {selectedProject.role}
                      </p>
                    </div>
                    <div>
                      <p className="font-display text-[9px] font-bold tracking-[0.28em] text-muted-foreground mb-1.5">
                        PERIOD
                      </p>
                      <p className="text-foreground text-sm">
                        {selectedProject.duration}
                      </p>
                    </div>
                    <div>
                      <p className="font-display text-[9px] font-bold tracking-[0.28em] text-muted-foreground mb-1.5">
                        TOOLS
                      </p>
                      <p className="text-foreground text-sm leading-relaxed">
                        {selectedProject.tools.join(" · ")}
                      </p>
                    </div>
                  </div>

                  {/* Overview */}
                  <div className="mb-8">
                    <p className="font-display text-[9px] font-bold tracking-[0.28em] text-primary mb-3">
                      OVERVIEW
                    </p>
                    <p className="text-foreground/80 leading-relaxed">
                      {selectedProject.overview}
                    </p>
                  </div>

                  {/* Key highlights */}
                  <div className="mb-8">
                    <p className="font-display text-[9px] font-bold tracking-[0.28em] text-primary mb-4">
                      KEY HIGHLIGHTS
                    </p>
                    <ul className="space-y-3.5">
                      {selectedProject.details.map((d, i) => (
                        <li
                          key={i}
                          className="flex gap-3 text-foreground/80 text-sm leading-relaxed"
                        >
                          <span className="text-primary shrink-0 mt-0.5 font-bold">
                            —
                          </span>
                          <span>{d}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Second image */}
                  {selectedProject.images[1] && (
                    <div className={`w-full overflow-hidden ${isFullscreen ? "bg-transparent" : "bg-secondary"}`}>
                      <img
                        src={selectedProject.images[1]}
                        alt={`${selectedProject.title} 상세 이미지`}
                        className={isFullscreen ? "mx-auto max-w-full h-auto" : "w-full h-auto"}
                      />
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}