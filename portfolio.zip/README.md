
  # portfolio

  This is a code bundle for portfolio. The original project is available at https://www.figma.com/design/1mA2AO3lemrRG58sYDo4Bi/portfolio.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  