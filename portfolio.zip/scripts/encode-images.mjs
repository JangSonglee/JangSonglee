/**
 * 이미지 → projectImages.ts 자동 업데이트 스크립트
 *
 * 사용법:
 *   node scripts/encode-images.mjs
 *
 * src/assets/projects/ 하위 폴더의 이미지를 읽어
 * src/app/projectImages.ts 를 자동으로 재생성합니다.
 */

import fs from "fs";
import path from "path";

const ASSETS_DIR = new URL("../src/assets/projects", import.meta.url).pathname;
const OUT_FILE   = new URL("../src/app/projectImages.ts", import.meta.url).pathname;

const IMAGE_EXTS = [".jpg", ".jpeg", ".png", ".webp", ".gif"];
const MIME = { ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png", ".webp": "image/webp", ".gif": "image/gif" };

function toBase64(filePath) {
  const ext  = path.extname(filePath).toLowerCase();
  const data = fs.readFileSync(filePath).toString("base64");
  return `data:${MIME[ext]};base64,${data}`;
}

/* 프로젝트 목록 — 이미지가 없어도 항상 키를 유지 */
const ALL_PROJECTS = [
  "01_cafe-app",
  "02_ecommerce",
  "03_fintech-dashboard",
  "04_travel-app",
  "05_brand-website",
  "06_smarthome-app",
  "07_movie-poster",
];

/* 실제 존재하는 폴더만 읽고, 없으면 빈 배열로 처리 */
const projects = ALL_PROJECTS;

const varLines   = [];   // const p07_thumb = "...";
const entryLines = [];   // "07_movie-poster": { ... }

for (const proj of projects) {
  const dir   = path.join(ASSETS_DIR, proj);
  const files = fs.existsSync(dir)
    ? fs.readdirSync(dir).filter(f => IMAGE_EXTS.includes(path.extname(f).toLowerCase()))
    : [];

  if (files.length === 0) {
    entryLines.push(`  "${proj}": { thumb: EMPTY, detail01: EMPTY, detail02: EMPTY },`);
    console.log(`  skip  ${proj}/ (이미지 없음)`);
    continue;
  }

  const key   = proj.replace(/[^a-zA-Z0-9]/g, "_");
  const thumb    = files.find(f => f.startsWith("thumb"))    || "";
  const detail01 = files.find(f => f.startsWith("detail-01")) || "";
  const detail02 = files.find(f => f.startsWith("detail-02")) || "";

  const thumbVar    = thumb    ? `_${key}_thumb`    : "EMPTY";
  const detail01Var = detail01 ? `_${key}_detail01` : "EMPTY";
  const detail02Var = detail02 ? `_${key}_detail02` : (detail01 ? `_${key}_detail01` : "EMPTY");

  if (thumb)    { varLines.push(`const ${thumbVar}    = "${toBase64(path.join(dir, thumb))}";`);    console.log(`  ✓  ${proj}/thumb`); }
  if (detail01) { varLines.push(`const ${detail01Var} = "${toBase64(path.join(dir, detail01))}";`); console.log(`  ✓  ${proj}/detail-01`); }
  if (detail02) { varLines.push(`const ${detail02Var} = "${toBase64(path.join(dir, detail02))}";`); console.log(`  ✓  ${proj}/detail-02`); }

  entryLines.push(
    `  "${proj}": { thumb: ${thumbVar}, detail01: ${detail01Var}, detail02: ${detail02Var} },`
  );
}

const output = `/**
 * ⚠️  이 파일은 자동 생성됩니다. 직접 수정하지 마세요.
 *    이미지를 추가/교체한 후 아래 명령어를 실행하세요:
 *    node scripts/encode-images.mjs
 */

const EMPTY = "";

${varLines.join("\n")}

export const projectImages: Record<string, { thumb: string; detail01: string; detail02: string }> = {
${entryLines.join("\n")}
};
`;

fs.writeFileSync(OUT_FILE, output);
console.log(`\n✅ projectImages.ts 업데이트 완료`);
